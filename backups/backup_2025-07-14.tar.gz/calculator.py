num1 = int(input("enter first number: "))
num2 = int(input("enter second number: "))

print(type(num1))
print(type(num2))

sum_of_num = num1 + num2

print("sum of 2 numbers: ",sum_of_num)

diff_of_num = num1 - num2
print("diff of 2 numbers: ",diff_of_num)

prod_of_num = num1 * num2

print("product of 2 numbers: ",prod_of_num)

div_of_num = num1 / num2

print("division of 2 numbers: ",div_of_num)




