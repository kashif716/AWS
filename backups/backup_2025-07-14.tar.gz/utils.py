import os       # importing a library into your code

print(os.system('df -h'))

print(os.system("uptime"))

print(os.system("free -h"))